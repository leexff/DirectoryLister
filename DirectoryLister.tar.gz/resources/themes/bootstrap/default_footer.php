<footer class="container">
  <div class="footer">
 © 2019-<?php echo date("Y")?> <a href="https://doub.io" target="_blank">Vito.无关风月</a> . All rights reserved.
   </div>
</footer>
